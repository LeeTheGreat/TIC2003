#pragma once
#include "DescriberClSelect.h"

class BuilderFullSqlSelect {
public:
	string GetSql(DescriberClSelect describer);
};