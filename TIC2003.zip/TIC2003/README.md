# DB design
https://lucid.app/lucidchart/f3dd4fff-5e14-426e-9660-a087b381bde3/edit?viewport_loc=-229%2C-60%2C2219%2C1108%2C0_0&invitationId=inv_5bb7d6e5-239d-4d4e-bec7-ca34d6dcb63f

# Class diagram
https://miro.com/welcomeonboard/N25hZ3VvMWY0bW42c0tUamRvem94UmpadHQ0ZmIxSEx0ZGFEaUZEcktmTmp4WGZXQ2IzU0JPM2FEWkp1bWNUUnwzNDU4NzY0NTQzMzY4Nzc2NTY5fDI=?share_link_id=40637267126

# Tasking
https://docs.google.com/document/d/1wz7z3CZqi4ypNXZK6oKxiFp_WPf2AE0r7FTidXWOGa4/edit?usp=sharing

# lteration 1 Report
https://docs.google.com/document/d/1CV7otxATjUSHi6X-XMz9IOpijloG6mo-uRkFm-vgz20/edit?usp=sharing

# lteration 2 Report
https://docs.google.com/document/d/141C-LXEx03YDosne7JGE2cusOxzt1lSE_h9qrDzEezg/edit?usp=sharing

# lteration 3 Report
